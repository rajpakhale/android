package com.example.assignment1_1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    Button red,green,blue,activity2Btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main);

        tv = (TextView) findViewById(R.id.textview); red = (Button) findViewById(R.id.red); green = (Button) findViewById(R.id.green); blue = (Button) findViewById((R.id.blue)); activity2Btn = (Button)
                findViewById(R.id.activity2Btn);

        red.setOnClickListener(new View.OnClickListener() { @Override
        public void onClick(View view) { tv.setTextColor(Color.RED);
        }
        });

        green.setOnClickListener(new View.OnClickListener() { @Override
        public void onClick(View view) { tv.setTextColor(Color.GREEN);
        }
        });

        blue.setOnClickListener(new View.OnClickListener() { @Override
        public void onClick(View view) { tv.setTextColor(Color.BLUE);
        }

        });

        activity2Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


            }
        });






    }
}

