package com.example.assignment1_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    Button small,medium,large;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main);

        tv = (TextView) findViewById(R.id.textview); small = (Button) findViewById(R.id.small); medium = (Button) findViewById(R.id.medium); large = (Button) findViewById(R.id.large);

        small.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { tv.setTextSize(10);
            }
        });
        medium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { tv.setTextSize(50);
            }
        });
        large.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) { tv.setTextSize(90);
            }
        });
    }
}
