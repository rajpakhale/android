package com.example.assignment1_4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    TextView answer;
    EditText getVal;
    Button ansBtn,clearBtn; RadioButton c2f,f2c; Double x;

    @Override
    protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main);
        ansBtn = (Button) findViewById(R.id.ansBtn); clearBtn = (Button) findViewById(R.id.clearBtn); getVal = (EditText) findViewById(R.id.getVal); answer = (TextView) findViewById(R.id.answer); c2f = (RadioButton) findViewById(R.id.c2f);
        f2c = (RadioButton) findViewById(R.id.f2c);

        ansBtn.setOnClickListener(new View.OnClickListener() { @Override
        public void onClick(View view) { if(getVal.getText().toString().isEmpty()){
            answer.setText("Enter Temperature");

        }else{
            x = Double.parseDouble(String.valueOf(getVal.getText()));
            if(c2f.isChecked()){ x = (x*9) / 5 + 32;
                x = Double.parseDouble(new DecimalFormat("##.###").format(x));

                answer.setText(String.valueOf(x) + "Degree F");



            }else if(f2c.isChecked()){ x = (x - 32) * 5/9;
                x = Double.parseDouble(new

                        DecimalFormat("##.###").format(x));
                answer.setText(String.valueOf(x) + " Degree C");


            }else{
                answer.setText("Please select an option !");

            }
        }
        }
        });

        clearBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) { answer.setText("0.0");
                getVal.setText(""); c2f.setChecked(false); f2c.setChecked(false);
            }
        });

    }
}
