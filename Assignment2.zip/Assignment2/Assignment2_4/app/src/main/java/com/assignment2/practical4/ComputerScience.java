package com.assignment2.practical4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ComputerScience extends AppCompatActivity {

    ListView comSciCourseListView;
    ArrayList<String> courses;
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_computer_science);
        getSupportActionBar().setTitle("Department of computer science");
        comSciCourseListView = (ListView) findViewById(R.id.comSciCourselistView);
        courses = new ArrayList<>();
        courses.add("M.C.A.");
        courses.add("Ph.D.");
        adapter =new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, courses);
        comSciCourseListView.setAdapter(adapter);
        comSciCourseListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String cname = (String) adapterView.getItemAtPosition(i);
                if(i == 0){
                    startActivity(new Intent(ComputerScience.this, MCA.class));
                }
                else if (i == 1){
                    startActivity(new Intent(ComputerScience.this, Phd.class));
                }
                else{
                    Toast.makeText(getApplicationContext(), "Create Content for " + cname , Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}