package com.assignment2.practical4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Law extends AppCompatActivity {

    ListView lawCourseListView;
    ArrayList<String> courses;
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_law);
        getSupportActionBar().setTitle("Department of law");
        lawCourseListView = (ListView)
                findViewById(R.id.lawCourselistView);
        courses = new ArrayList<>();
        courses.add("B.com LL.B.");
        adapter =new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_1, courses);
        lawCourseListView.setAdapter(adapter);
        lawCourseListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String cname = (String) adapterView.getItemAtPosition(i);
                if(i == 0){
                    startActivity(new Intent(Law.this, BComLLB.class));
                }else{
                    Toast.makeText(getApplicationContext(), "Create Content for " + cname , Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}