package com.assignment1.practical5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textview,resultTextView,count;
    Button getVal;
    CheckBox java,c,cp,php,python;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textview = (TextView) findViewById(R.id.textview);
        resultTextView = (TextView) findViewById(R.id.resultTextView);
        count = (TextView) findViewById(R.id.count);
        getVal = (Button) findViewById(R.id.getVal);
        java = (CheckBox) findViewById(R.id.javaCheck);
        c = (CheckBox) findViewById(R.id.cCheck);
        cp = (CheckBox) findViewById(R.id.cpCheck);
        php = (CheckBox) findViewById(R.id.phpCheck);
        python = (CheckBox) findViewById(R.id.pythonCheck);
        getVal.setOnClickListener(new View.OnClickListener() {
            String Answer="";
            int i = 0;
            @Override
            public void onClick(View view) {
                Answer = "";
                i = 0;
                if(java.isChecked()){
                    Answer += "\n" + java.getText().toString();
                    ++i;
                }
                if(c.isChecked()){
                    Answer += "\n" + c.getText().toString();
                    ++i;
                }
                if(cp.isChecked()){
                    Answer += "\n" + cp.getText().toString();
                    ++i;
                }
                if(php.isChecked()){
                    Answer += "\n" + php.getText().toString();
                    ++i;
                }
                if(python.isChecked()){
                    Answer += "\n" + python.getText().toString();
                    ++i;
                }
                resultTextView.setText(Answer);
                count.setText("You have selected "+i+" items");
            }
        });
    }

}