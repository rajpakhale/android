package com.assignment2.practical4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MCA extends AppCompatActivity {

    TextView description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mca);
        getSupportActionBar().setTitle("MCA");
        description=findViewById(R.id.mca_desc);
        description.setText("Master of Computer Application (MCA) program is\n" +
                "specially designed for computer science, information technology,\n" +
                "engineering, etc graduate students. Although non-IT graduates can\n" +
                "also pursue the program. There is a bridge course compulsory for\n" +
                "such graduates, which will bridge the gap between subjects studied\n" +
                "at the graduate level and subjects they would be studying at Master\n" +
                "of Computer Application. Such graduates have to clear the bridge\n" +
                "course and get 16 credits during the completion of the MCA program.\n" +
                "The curriculum is designed and updated regularly to match the IT\n" +
                "industry’s needs. The program was of 3 years duration,but from the\n" +
                "academic year 2020-21, it is of two years duration.");

    }
}