package com.assignment2.practical4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Phd extends AppCompatActivity {

    TextView description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phd);
        getSupportActionBar().setTitle("Phd");
        description=findViewById(R.id.phd_desc);
        description.setText("Since the establishment, department provide\n" +
                "a creative and stimulation environment to students. Department\n" +
                "offer the PG course in Theoretical Physics, Materials Science\n" +
                "and Electronics. Course curriculum is designed as per UGC\n" +
                "guidelines with the projects work in the last semester. The key\n" +
                "research areas of the department are Crystal Growth,\n" +
                "Theoretical Nuclear and Particle Physics, Digital\n" +
                "communication, Thin Film and Electronic devices etc.\n" +
                "Department inspires students to participate in summer and\n" +
                "winter schools at TIFR, BARC, PRL etc. Department also\n" +
                "regularly organized the popular talks on Nobel Prize in Physics,\n" +
                "Popularization of science and on Theoretical Physics. The\n" +
                "department has provided skilled manpower in physics and\n" +
                "related fields. Many past students are presently serving in the\n" +
                "state and national level institute, university and colleges\n" +
                "indicates our credit in the scientific community and society.");
    }
}