package com.assignment2.practical7;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class CustomAdapter extends ArrayAdapter<String> {

    private Context context;
    private List<String> listvalues;
    private TextView listitem;

    public CustomAdapter(@NonNull Context context, int resource, @NonNull List<String> listvalues) {
        super(context, resource, listvalues);
        this.context=context;
        this.listvalues=listvalues;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        String currentvalue = listvalues.get(position);
        LayoutInflater inflater = LayoutInflater.from(context);

        convertView = inflater.inflate(R.layout.list_item,null);

        listitem = convertView.findViewById(R.id.item);
        listitem.setText(currentvalue);
        return convertView;
    }

    @Override
    public int getCount() {
        Intent i = ((Activity) context).getIntent();
        int number = i.getIntExtra("number",super.getCount());
        Integer originalcount = super.getCount();

        if(number > super.getCount()){
            Toast.makeText(context,"Value can not be more than " + originalcount.toString(), Toast.LENGTH_SHORT).show();
            ((Activity) context).finish();
        }else if(number == 0){
            Toast.makeText(context,"please enter a valid value", Toast.LENGTH_SHORT).show();
            ((Activity) context).finish();
        }
        return number;
    }
}
