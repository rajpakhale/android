package com.example.practiceapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class contentprovider extends AppCompatActivity {

    ListView contactlist;
    ArrayList mobile, number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contentprovider);
        getSupportActionBar().setTitle("Content Provider");

        number = new ArrayList();

        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED)
        {
            mobile = getcontacts();
        } else {
            requestPermission();
        }

        ArrayAdapter adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,android.R.id.text1,mobile);
        contactlist=findViewById(R.id.contactlist);

        contactlist.setAdapter(adapter);

        contactlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String num = (String) number.get(i);
                Toast.makeText(contentprovider.this,num,Toast.LENGTH_LONG).show();
            }
        });
    }

    private void requestPermission(){
        if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.READ_CONTACTS)){

        }else{
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_CONTACTS},79);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestcode,
                                          String permissions[],int[] grantResults) {
        super.onRequestPermissionsResult(requestcode, permissions, grantResults);

        switch(requestcode){
            case 79:{
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    mobile = getcontacts();
                }
                else{

                }
                return;
            }

        }
    }

    @SuppressLint("Range")
    private ArrayList getcontacts(){
        ArrayList<String> namelist = new ArrayList<>();
        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,null,null,null,null);

        if((cur != null ? cur.getCount() : 0) > 0 ){
            while(cur != null && cur.moveToNext()){
                @SuppressLint("Range") String id = cur.getString(
                        cur.getColumnIndex(ContactsContract.Contacts._ID)
                );
                @SuppressLint("Range") String name = cur.getString(
                        cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)
                );
                namelist.add(name);

                if(cur.getInt(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0){
                    Cursor pcur = cr.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " =?",
                            new String[]{id},null
                    );

                    while(pcur.moveToNext()){
                        String phoneno = pcur.getString(
                                pcur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        );
                        number.add(phoneno);
                    }
                    pcur.close();
                }
            }
        }
        if(cur != null){
            cur.close();
        }
        return namelist;
    }
}