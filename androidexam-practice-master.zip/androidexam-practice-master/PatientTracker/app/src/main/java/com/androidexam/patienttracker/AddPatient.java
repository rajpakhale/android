package com.androidexam.patienttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Calendar;

public class AddPatient extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    EditText patientname,disease,medication,arrival,cost;
    Button addpatient;
    Integer year,month,day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_patient);
        patientname=findViewById(R.id.PatientName);
        disease=findViewById(R.id.PatientDisease);
        medication=findViewById(R.id.PatientMedication);
        arrival=findViewById(R.id.DateofArrival);
        cost=findViewById(R.id.PatientCost);
        addpatient=findViewById(R.id.AddBtn);

        arrival.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calender = Calendar.getInstance();
                year=calender.get(Calendar.YEAR);
                month=calender.get(Calendar.MONTH);
                day=calender.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dialog = new DatePickerDialog(AddPatient.this,AddPatient.this,year,month,day);
                dialog.show();
            }
        });

        addpatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PatientDB db = new PatientDB(AddPatient.this,"PatientDB",null,1);
                db.addData(patientname.getText().toString(),disease.getText().toString()
                        ,medication.getText().toString(),arrival.getText().toString(),Integer.parseInt(cost.getText().toString()));
                Intent i = new Intent(AddPatient.this,MainActivity.class);
                startActivity(i);
            }
        });
    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
        arrival.setText(day+"-"+month+"-"+year);
    }
}