package com.androidexam.patienttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Calendar;

public class EditPatient extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    EditText name,disease,medication,date,cost;
    Integer id;
    Button savebtn;
    Integer year,month,day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_patient);
        name=findViewById(R.id.Name);
        disease=findViewById(R.id.Disease);
        medication=findViewById(R.id.Medication);
        date=findViewById(R.id.Arrival);
        cost=findViewById(R.id.Cost);
        savebtn=findViewById(R.id.UpdateBtn);

        Intent i = getIntent();
        name.setText(i.getStringExtra("Name"));
        disease.setText(i.getStringExtra("Disease"));
        medication.setText(i.getStringExtra("Medication"));
        date.setText(i.getStringExtra("Date"));
        cost.setText(i.getStringExtra("Cost"));
        id=Integer.parseInt(i.getStringExtra("ID"));

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calender = Calendar.getInstance();
                year=calender.get(Calendar.YEAR);
                month=calender.get(Calendar.MONTH);
                day=calender.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dialog = new DatePickerDialog(EditPatient.this,EditPatient.this,year,month,day);
                dialog.show();
            }
        });

        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PatientDB db = new PatientDB(EditPatient.this,"PatientDB",null,1);
                db.UpdateData(id,name.getText().toString(),disease.getText().toString(),medication.getText().toString(),
                        date.getText().toString(),Integer.parseInt(cost.getText().toString()));
                Intent i = new Intent(EditPatient.this,MainActivity.class);
                startActivity(i);
            }
        });
    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
        date.setText(day+"-"+month+"-"+year);
    }
}