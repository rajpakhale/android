package com.androidexam.patienttracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView patientlist;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actions,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.m1:
                Intent i = new Intent(MainActivity.this,AddPatient.class);
                startActivity(i);
                break;

            case R.id.m2:
                Intent i2 = new Intent(MainActivity.this,PatientDetail.class);
                startActivity(i2);
                break;
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        patientlist=findViewById(R.id.patientlist);

        PatientDB patients = new PatientDB(this,"PatientDB",null,1);
        final List<String> namelist = patients.Patientlist();

        final ArrayAdapter<String> adp = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,namelist);
        patientlist.setAdapter(adp);


    }
}