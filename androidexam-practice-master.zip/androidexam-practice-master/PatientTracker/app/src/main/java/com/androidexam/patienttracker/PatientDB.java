package com.androidexam.patienttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class PatientDB extends SQLiteOpenHelper {
    public PatientDB(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "PatientDB", factory, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table PatientDB (PatientID integer primary key autoincrement,Name text,disease text,medication text,date text,cost integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists PatientDB");
    }

    public void addData(String name,String disease,String medication,String date,Integer cost){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Name",name);
        cv.put("disease",disease);
        cv.put("medication",medication);
        cv.put("date",date);
        cv.put("cost",cost);
        db.insert("PatientDB",null,cv);
        db.close();
    }

    public void UpdateData(Integer id,String name,String disease,String medication,String date,Integer cost){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Name",name);
        cv.put("disease",disease);
        cv.put("medication",medication);
        cv.put("date",date);
        cv.put("cost",cost);
        db.update("PatientDB",cv,"PatientID=?",new String[]{id.toString()});
        db.close();
    }

    public void DeleteData(Integer id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("PatientDB","PatientID=?",new String[]{id.toString()});
        db.close();
    }

    public Cursor PatientData(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from PatientDB where Name=?",new String[]{name});
        return res;
    }

    public List<String> Patientlist(){
        SQLiteDatabase db = this.getWritableDatabase();
        List<String> patientlist = new ArrayList<>();
        Cursor res = db.rawQuery("select Name from PatientDB",null);
        while(res.moveToNext())
        {
            patientlist.add(res.getString(0));
        }
        return patientlist;
    }
}
