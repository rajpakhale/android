package com.androidexam.patienttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;

public class PatientDetail extends AppCompatActivity {

    AutoCompleteTextView patientnames;
    Button search,edit,delete;
    TextView id,name,disease,medication,cost,date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_detail);
        patientnames=findViewById(R.id.SearchPatient);
        search=findViewById(R.id.Searchbtn);
        id=findViewById(R.id.PatientIDView);
        name=findViewById(R.id.PatientNameView);
        disease=findViewById(R.id.PatientDiseaseView);
        medication=findViewById(R.id.MedicationView);
        cost=findViewById(R.id.CostView);
        date=findViewById(R.id.DateView);
        edit=findViewById(R.id.Editbtn);
        delete=findViewById(R.id.deletebtn);
        PatientDB names = new PatientDB(this,"PatientDB",null,1);
        ArrayAdapter adp = new ArrayAdapter(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,names.Patientlist());
        patientnames.setAdapter(adp);
        patientnames.setThreshold(1);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = names.PatientData(patientnames.getText().toString());
                while (res.moveToNext()){
                    id.setText(res.getString(0));
                    name.setText(res.getString(1));
                    disease.setText(res.getString(2));
                    medication.setText(res.getString(3));
                    date.setText(res.getString(4));
                    cost.setText(res.getString(5));
                }

            }
        });

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PatientDetail.this,EditPatient.class);
                i.putExtra("ID",id.getText().toString());
                i.putExtra("Name",name.getText().toString());
                i.putExtra("Disease",disease.getText().toString());
                i.putExtra("Medication",medication.getText().toString());
                i.putExtra("Date",date.getText().toString());
                i.putExtra("Cost",cost.getText().toString());
                startActivity(i);
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                names.DeleteData(Integer.parseInt(id.getText().toString()));
                Intent i = new Intent(PatientDetail.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}